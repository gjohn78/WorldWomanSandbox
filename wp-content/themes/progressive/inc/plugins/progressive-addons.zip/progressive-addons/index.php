<?php
/*
Plugin Name: Progressive Addons
Plugin URI: http://themeforest.net/user/JoiThemes
Description: A part of Progressive theme
Version: 1.0
Author: Joi Team
Author URI: http://themeforest.net/user/JoiThemes
Text Domain: progressive-addons
*/

// Define Constants
 defined('RS_ROOT') or define('RS_ROOT', dirname(__FILE__));

/**
 * Custom posts
 */
require_once(RS_ROOT .'/custom-posts.php');